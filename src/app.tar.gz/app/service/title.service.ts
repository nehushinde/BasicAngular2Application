import { Injectable } from '@angular/core';
@Injectable()
export class ExampleService {
    someMethod() {
        console.log('check');
        return 'Welcome';
    }
    
}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';

import { AppComponent } from './component/app.component';
import { AddsComponent } from './component/adds.component';
import { GalleryComponent } from './component/gallery.component';
import { DetailComponent } from './component/detail.component'; 
import { HomeComponent } from './component/home.component';
import { RouteLinkComponent } from './component/routelink.component';


const appRoutes: Routes=[
  { path: '' ,component:HomeComponent },
  { path: 'gallery' ,component:GalleryComponent },
  { path: 'adds' ,component:AddsComponent },
  { path: 'details' ,component:DetailComponent },

];

@NgModule({
  declarations: [
    AppComponent,
    AddsComponent,
    GalleryComponent,
    DetailComponent,
    HomeComponent,
    RouteLinkComponent

    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component } from '@angular/core';
@Component({
    selector: 'app-home',
    templateUrl: '../view/home.component.html',
    styleUrls: ['../app.component.css']
    
})
export class HomeComponent{

    onLoadGallery(){}
}
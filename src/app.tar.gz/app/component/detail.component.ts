import { Component } from '@angular/core';
@Component({
    selector:'app-detail',
    templateUrl:'../view/detail.component.html',
    styleUrls:['../app.component.css']
})
export class DetailComponent{

}
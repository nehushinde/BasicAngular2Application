import { Component } from '@angular/core';
@Component({
    selector:'app-gallery',
    templateUrl: '../view/gallery.component.html',
    styleUrls: ['../app.component.css']  
})
export class GalleryComponent{

}
import { Component} from '@angular/core';
@Component({
    selector:'app-adds',
    templateUrl:'../view/adds.component.html',
    styleUrls:['../app.component.css']
})
export class AddsComponent{
}
import { Component } from '@angular/core';
@Component({
    selector:'app-routelink',
    templateUrl:'../view/routelink.component.html',
    styleUrls:['../app.component.css']
})
export class RouteLinkComponent{
    
}